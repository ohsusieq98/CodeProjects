var i18n = {
    "Bunnies splattered": "溅洒的兔子一共有：",
    "Bunnies eviscerated":"毁掉的兔子一共有",
    "Bunnies mutilated": "切断的兔子一共有",
    "Bunnies massacred": "残杀的兔子一共有",
    "Bunnies butchered": "屠杀的兔子一共有",
    "reload your shotgun!": "重新装子弹！",  
    "make the killing stop!": "不要再杀了！",
    "splattered": "打死的兔子有",
    "Images loaded: ": "加载图片：",
    "The bunnies of the world thank you for your pacifism. Happy Easter!": "世界上的兔子对你和平主义态度表示感谢！复活节快乐！", 
    " Level ": " 轮", 
    "Bunny Hunt IV": "寻找兔子 4", 
    "The Good Friday Massacre": "受难日大屠杀", 
    "let\'s shoot some bunnies!": "咱们去打猎吧！"
    
    
    
    
}